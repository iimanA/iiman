package com.example.assign1.models

data class LatitudeLongitude(
    val latitude: Float,
    val longitude: Float,

    )
